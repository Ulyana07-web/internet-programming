import sqlite3

connection = sqlite3.connect('db.sqlite3')
    
    # Создание таблицы из SQL-файла
with open('/Users/ulyana/Downloads/myshop/main/catalog.sql', 'r', encoding='utf-8') as f:
    connection.executescript(f.read())
    
    # Создание курсора
cur = connection.cursor()
    
    # Данные, которые мы хотим вставить
name = "стол"
price = 100.00  # Убедитесь, что цена — это число, а не строка
    
    # Вставка данных
cur.execute("INSERT INTO products (name, price) VALUES (?, ?)", (name, price))
    
    # Подтверждение изменений
connection.commit()
    

cur.close()
connection.close()